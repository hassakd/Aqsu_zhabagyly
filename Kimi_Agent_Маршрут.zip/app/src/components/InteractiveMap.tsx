import { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents } from 'react-leaflet';
import { MapPin, Navigation, Layers, LocateFixed, MousePointer, Trash2 } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default icons
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom icons
const reserveIcon = L.divIcon({
  className: 'custom-marker',
  html: `<div style="
    width: 40px; 
    height: 40px; 
    background: linear-gradient(135deg, #00AFCA, #008fa8); 
    border-radius: 50% 50% 50% 0; 
    transform: rotate(-45deg); 
    display: flex; 
    align-items: center; 
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0,175,202,0.4);
    border: 3px solid white;
  ">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="transform: rotate(45deg);">
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
      <circle cx="12" cy="10" r="3"/>
    </svg>
  </div>`,
  iconSize: [40, 40],
  iconAnchor: [20, 40]
});

const userIcon = L.divIcon({
  className: 'custom-marker-user',
  html: `<div style="
    width: 36px; 
    height: 36px; 
    background: linear-gradient(135deg, #FEC50C, #e5b00b); 
    border-radius: 50%; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    box-shadow: 0 4px 12px rgba(254,197,12,0.4);
    border: 3px solid white;
  ">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a2e" stroke-width="2.5">
      <circle cx="12" cy="12" r="3"/>
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
  </div>`,
  iconSize: [36, 36],
  iconAnchor: [18, 18]
});

const clickIcon = L.divIcon({
  className: 'custom-marker-click',
  html: `<div style="
    width: 36px; 
    height: 36px; 
    background: linear-gradient(135deg, #10B981, #059669); 
    border-radius: 50%; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    box-shadow: 0 4px 12px rgba(16,185,129,0.4);
    border: 3px solid white;
  ">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
      <circle cx="12" cy="10" r="3"/>
    </svg>
  </div>`,
  iconSize: [36, 36],
  iconAnchor: [18, 36]
});

// Map controller component
function MapController({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

// Click handler for map
function MapClickHandler({ 
  onMapClick, 
  isSelectingPoint 
}: { 
  onMapClick: (lat: number, lng: number) => void;
  isSelectingPoint: boolean;
}) {
  useMapEvents({
    click(e) {
      if (isSelectingPoint) {
        onMapClick(e.latlng.lat, e.latlng.lng);
      }
    }
  });
  return null;
}

// Routing control component
function RoutingControl({ 
  from, 
  to 
}: { 
  from: [number, number] | null; 
  to: [number, number]; 
}) {
  const map = useMap();
  const routingControlRef = useRef<L.Routing.Control | null>(null);

  useEffect(() => {
    if (!from) return;

    // Dynamically import leaflet-routing-machine
    import('leaflet-routing-machine').then(() => {
      if (routingControlRef.current) {
        map.removeControl(routingControlRef.current);
      }

      const routingControl = L.Routing.control({
        waypoints: [
          L.latLng(from[0], from[1]),
          L.latLng(to[0], to[1])
        ],
        routeWhileDragging: true,
        showAlternatives: true,
        fitSelectedRoutes: true,
        lineOptions: {
          styles: [{ color: '#00AFCA', weight: 6, opacity: 0.8 }],
          extendToWaypoints: true,
          missingRouteTolerance: 0
        } as any,
        altLineOptions: {
          styles: [{ color: '#FEC50C', weight: 4, opacity: 0.6 }],
          extendToWaypoints: true,
          missingRouteTolerance: 0
        } as any
      } as any);

      routingControl.addTo(map);
      routingControlRef.current = routingControl;
    });

    return () => {
      if (routingControlRef.current) {
        map.removeControl(routingControlRef.current);
      }
    };
  }, [from, to, map]);

  return null;
}

export default function InteractiveMap() {
  // Reserve coordinates (Aksu-Zhabagly)
  const reservePosition: [number, number] = [42.3667, 70.6167];
  
  const [userPosition, setUserPosition] = useState<[number, number] | null>(null);
  const [clickedPosition, setClickedPosition] = useState<[number, number] | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSelectingPoint, setIsSelectingPoint] = useState(false);
  const [mapCenter, setMapCenter] = useState<[number, number]>(reservePosition);
  const [showRoute, setShowRoute] = useState(false);
  const [mapType, setMapType] = useState<'street' | 'satellite'>('street');

  // Get user location
  const locateUser = () => {
    setIsLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos: [number, number] = [position.coords.latitude, position.coords.longitude];
          setUserPosition(pos);
          setClickedPosition(null);
          setMapCenter(pos);
          setIsLocating(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Не удалось определить ваше местоположение. Пожалуйста, проверьте настройки геолокации.');
          setIsLocating(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      alert('Геолокация не поддерживается вашим браузером');
      setIsLocating(false);
    }
  };

  // Handle map click
  const handleMapClick = (lat: number, lng: number) => {
    setClickedPosition([lat, lng]);
    setUserPosition(null);
    setIsSelectingPoint(false);
  };

  // Enable point selection mode
  const enablePointSelection = () => {
    setIsSelectingPoint(true);
    setShowRoute(false);
  };

  // Build route
  const buildRoute = () => {
    const startPoint = userPosition || clickedPosition;
    if (!startPoint) {
      alert('Пожалуйста, выберите точку отправления: определите местоположение или кликните на карте');
      return;
    }
    setShowRoute(true);
  };

  // Reset route
  const resetRoute = () => {
    setShowRoute(false);
    setUserPosition(null);
    setClickedPosition(null);
    setIsSelectingPoint(false);
    setMapCenter(reservePosition);
  };

  // Get current start point
  const getStartPoint = (): [number, number] | null => {
    return userPosition || clickedPosition;
  };

  return (
    <div className="w-full">
      {/* Map Controls */}
      <div className="flex flex-wrap gap-3 mb-4">
        <button
          onClick={locateUser}
          disabled={isLocating}
          className="flex items-center gap-2 px-4 py-2 bg-kazakh-blue text-white rounded-lg hover:bg-opacity-90 transition-all disabled:opacity-50"
        >
          <LocateFixed className={`w-5 h-5 ${isLocating ? 'animate-spin' : ''}`} />
          {isLocating ? 'Определение...' : 'Моё местоположение'}
        </button>
        
        <button
          onClick={enablePointSelection}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
            isSelectingPoint 
              ? 'bg-green-500 text-white' 
              : 'bg-green-100 text-green-700 hover:bg-green-200'
          }`}
        >
          <MousePointer className="w-5 h-5" />
          {isSelectingPoint ? 'Кликните на карте' : 'Выбрать точку на карте'}
        </button>
        
        <button
          onClick={buildRoute}
          className="flex items-center gap-2 px-4 py-2 bg-kazakh-yellow text-kazakh-dark rounded-lg hover:bg-opacity-90 transition-all"
        >
          <Navigation className="w-5 h-5" />
          Построить маршрут
        </button>
        
        <button
          onClick={resetRoute}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all"
        >
          <Trash2 className="w-5 h-5" />
          Сбросить
        </button>
        
        <button
          onClick={() => setMapType(mapType === 'street' ? 'satellite' : 'street')}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all"
        >
          <Layers className="w-5 h-5" />
          {mapType === 'street' ? 'Спутник' : 'Карта'}
        </button>
      </div>

      {/* Selection Mode Indicator */}
      {isSelectingPoint && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
          <MousePointer className="w-5 h-5 text-green-600" />
          <span className="text-green-700 text-sm">
            <strong>Режим выбора точки:</strong> Кликните в любое место на карте, чтобы установить точку отправления
          </span>
        </div>
      )}

      {/* Selected Point Info */}
      {(userPosition || clickedPosition) && (
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-kazakh-blue" />
              <span className="text-kazakh-dark text-sm">
                <strong>Точка отправления:</strong>{' '}
                {userPosition ? 'Ваше местоположение' : 'Выбранная точка на карте'}
              </span>
            </div>
            {clickedPosition && (
              <span className="text-xs text-gray-500">
                {clickedPosition[0].toFixed(4)}°N, {clickedPosition[1].toFixed(4)}°E
              </span>
            )}
          </div>
        </div>
      )}

      {/* Map Container */}
      <div className="relative rounded-2xl overflow-hidden shadow-xl border border-gray-200">
        <div className={`h-[500px] w-full ${isSelectingPoint ? 'point-selection-mode' : ''}`}>
          <MapContainer
            center={mapCenter}
            zoom={10}
            scrollWheelZoom={true}
            className={isSelectingPoint ? 'point-selection-mode' : ''}
            style={{ height: '100%', width: '100%', cursor: isSelectingPoint ? 'crosshair' : 'grab' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url={mapType === 'street' 
                ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
                : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
              }
            />
            
            <MapController center={mapCenter} />
            <MapClickHandler onMapClick={handleMapClick} isSelectingPoint={isSelectingPoint} />
            
            {/* Reserve Marker */}
            <Marker position={reservePosition} icon={reserveIcon}>
              <Popup>
                <div className="p-2">
                  <h4 className="font-bold text-kazakh-dark">Аксу-Жабаглинский заповедник</h4>
                  <p className="text-sm text-gray-600">Центральный офис в с. Жабаглы</p>
                  <p className="text-xs text-gray-500 mt-1">42.3667°N, 70.6167°E</p>
                </div>
              </Popup>
            </Marker>

            {/* User Position Marker */}
            {userPosition && (
              <Marker position={userPosition} icon={userIcon}>
                <Popup>
                  <div className="p-2">
                    <h4 className="font-bold text-kazakh-dark">Ваше местоположение</h4>
                    <p className="text-xs text-gray-500">{userPosition[0].toFixed(4)}°N, {userPosition[1].toFixed(4)}°E</p>
                  </div>
                </Popup>
              </Marker>
            )}

            {/* Clicked Position Marker */}
            {clickedPosition && (
              <Marker position={clickedPosition} icon={clickIcon}>
                <Popup>
                  <div className="p-2">
                    <h4 className="font-bold text-kazakh-dark">Выбранная точка</h4>
                    <p className="text-xs text-gray-500">{clickedPosition[0].toFixed(4)}°N, {clickedPosition[1].toFixed(4)}°E</p>
                  </div>
                </Popup>
              </Marker>
            )}

            {/* Routing */}
            {showRoute && getStartPoint() && (
              <RoutingControl from={getStartPoint()} to={reservePosition} />
            )}
          </MapContainer>
        </div>

        {/* Map Legend */}
        <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg max-w-xs">
          <h4 className="font-bold text-kazakh-dark mb-3 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-kazakh-blue" />
            Легенда
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00AFCA] to-[#008fa8] flex items-center justify-center">
                <MapPin className="w-3 h-3 text-white" />
              </div>
              <span className="text-gray-700">Заповедник Аксу-Жабагылы</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#FEC50C] to-[#e5b00b] flex items-center justify-center">
                <LocateFixed className="w-3 h-3 text-kazakh-dark" />
              </div>
              <span className="text-gray-700">Ваше местоположение</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#10B981] to-[#059669] flex items-center justify-center">
                <MapPin className="w-3 h-3 text-white" />
              </div>
              <span className="text-gray-700">Выбранная точка</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-1 bg-[#00AFCA] rounded"></div>
              <span className="text-gray-700">Маршрут</span>
            </div>
          </div>
        </div>

        {/* Distance Info */}
        {getStartPoint() && showRoute && (
          <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg">
            <p className="text-sm text-gray-600">Расстояние по прямой:</p>
            <p className="text-2xl font-bold text-kazakh-blue">
              {Math.round(
                L.latLng(getStartPoint()!).distanceTo(L.latLng(reservePosition)) / 1000
              )} км
            </p>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="mt-4 p-4 bg-kazakh-blue/5 rounded-xl border border-kazakh-blue/20">
        <h4 className="font-bold text-kazakh-dark mb-2">Как построить маршрут:</h4>
        <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
          <li><strong>Способ 1:</strong> Нажмите "Моё местоположение" для автоматического определения</li>
          <li><strong>Способ 2:</strong> Нажмите "Выбрать точку на карте" и кликните в любое место</li>
          <li>Нажмите "Построить маршрут" для прокладки пути до заповедника</li>
          <li>Используйте колесо мыши для масштабирования карты</li>
        </ol>
      </div>
    </div>
  );
}
