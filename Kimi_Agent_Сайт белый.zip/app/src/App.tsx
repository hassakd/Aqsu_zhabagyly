import { useEffect, useRef, useState } from 'react';
import { 
  Mountain, 
  Leaf, 
  PawPrint, 
  MapPin, 
  Calendar, 
  Info, 
  ExternalLink,
  ChevronDown,
  Camera,
  Binoculars,
  Trees,
  Navigation as NavigationIcon
} from 'lucide-react';
import './App.css';
import InteractiveMap from './components/InteractiveMap';

// Animation hook for intersection observer
function useIntersectionObserver(options = {}) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.1, ...options });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return { ref, isVisible };
}

// Animated Section Component
function AnimatedSection({ 
  children, 
  className = '', 
  animation = 'fade-in-up',
  delay = 0
}: { 
  children: React.ReactNode; 
  className?: string; 
  animation?: string;
  delay?: number;
}) {
  const { ref, isVisible } = useIntersectionObserver();
  
  return (
    <div 
      ref={ref}
      className={`${className} ${isVisible ? `animate-${animation}` : 'opacity-0'}`}
      style={{ animationDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

// Navigation Component
function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#about', label: 'О заповеднике' },
    { href: '#fauna', label: 'Фауна' },
    { href: '#flora', label: 'Флора' },
    { href: '#landscapes', label: 'Пейзажи' },
    { href: '#visit', label: 'Посетить' },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled 
          ? 'bg-white/90 backdrop-blur-lg shadow-lg py-3' 
          : 'bg-transparent py-6'
      }`}
    >
      <div className="section-container flex items-center justify-between">
        <a 
          href="#" 
          className={`text-xl font-bold transition-colors duration-300 ${
            scrolled ? 'text-kazakh-blue' : 'text-white'
          }`}
        >
          Ақсу-Жабағылы
        </a>
        
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`text-sm font-medium link-underline transition-colors duration-300 ${
                scrolled ? 'text-gray-700 hover:text-kazakh-blue' : 'text-white/90 hover:text-white'
              }`}
            >
              {link.label}
            </a>
          ))}
        </div>

        <a
          href="https://www.unesco.org/en/mab/aksu-zhabagly"
          target="_blank"
          rel="noopener noreferrer"
          className={`hidden sm:flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
            scrolled 
              ? 'bg-kazakh-blue text-white hover:shadow-glow' 
              : 'bg-white/20 text-white backdrop-blur-sm hover:bg-white/30'
          }`}
        >
          UNESCO MAB
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </nav>
  );
}

// Hero Section
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-landscape.jpg"
          alt="Горы Аксу-Жабагылы"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 section-container text-center text-white pt-20">
        <AnimatedSection animation="fade-in-up" delay={200}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-6">
            <Mountain className="w-4 h-4 text-kazakh-yellow" />
            <span className="text-sm font-medium">UNESCO Biosphere Reserve</span>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fade-in-up" delay={400}>
          <h1 className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold mb-6 leading-tight">
            Ақсу-
            <span className="text-kazakh-yellow">Жабағылы</span>
          </h1>
        </AnimatedSection>

        <AnimatedSection animation="fade-in-up" delay={600}>
          <p className="text-xl sm:text-2xl lg:text-3xl font-light mb-4 text-white/90">
            — ғажайып әлем
          </p>
        </AnimatedSection>

        <AnimatedSection animation="fade-in-up" delay={800}>
          <p className="text-lg sm:text-xl text-white/80 max-w-2xl mx-auto mb-10">
            Старейший заповедник Центральной Азии, сокровищница уникальной природы 
            Западного Тянь-Шаня
          </p>
        </AnimatedSection>

        <AnimatedSection animation="fade-in-up" delay={1000}>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#about" className="btn-secondary flex items-center gap-2">
              <Info className="w-5 h-5" />
              Узнать больше
            </a>
            <a href="#visit" className="px-6 py-3 bg-white/10 backdrop-blur-sm text-white font-medium rounded-lg hover:bg-white/20 transition-all duration-300 flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Как добраться
            </a>
          </div>
        </AnimatedSection>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-8 h-8 text-white/60" />
      </div>
    </section>
  );
}

// About Section
function AboutSection() {
  const stats = [
    { value: '1926', label: 'Год основания', icon: Calendar },
    { value: '1312', label: 'Видов растений', icon: Leaf },
    { value: '330+', label: 'Видов животных', icon: PawPrint },
    { value: '4242', label: 'м. над уровнем моря', icon: Mountain },
  ];

  return (
    <section id="about" className="py-20 lg:py-32 bg-white">
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <AnimatedSection animation="slide-in-left">
            <div className="relative">
              <img
                src="/images/alpine-meadow.jpg"
                alt="Альпийский луг"
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-kazakh-yellow p-6 rounded-xl shadow-lg">
                <p className="text-3xl font-bold text-kazakh-dark">98</p>
                <p className="text-sm text-kazakh-dark/70">лет охраны природы</p>
              </div>
            </div>
          </AnimatedSection>

          <div>
            <AnimatedSection animation="fade-in-up">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-12 h-1 bg-kazakh-blue rounded-full" />
                <span className="text-kazakh-blue font-medium">О заповеднике</span>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={100}>
              <h2 className="section-title mb-6">
                Природное достояние <span className="text-gradient">Казахстана</span>
              </h2>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={200}>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Аксу-Жабаглинский государственный заповедник — первый заповедник в Центральной Азии, 
                основанный в 1926 году. Расположен на северо-западных отрогах Таласского Алатау 
                и юге Каратау в Западном Тянь-Шане.
              </p>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={300}>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Благодаря уникальным экосистемам и ландшафтам заповедник включен в сеть 
                биосферных резерватов <a href="https://www.unesco.org/en/mab" target="_blank" rel="noopener noreferrer" className="text-kazakh-blue hover:underline">UNESCO</a> и 
                является объектом <a href="https://whc.unesco.org" target="_blank" rel="noopener noreferrer" className="text-kazakh-blue hover:underline">Всемирного наследия</a>. 
                Здесь сохранились редчайшие виды флоры и фауны, многие из которых занесены в Красную книгу.
              </p>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={400}>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {stats.map((stat, index) => (
                  <div 
                    key={stat.label}
                    className="text-center p-4 bg-gray-50 rounded-xl hover-lift"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <stat.icon className="w-6 h-6 text-kazakh-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-kazakh-dark">{stat.value}</p>
                    <p className="text-xs text-gray-500">{stat.label}</p>
                  </div>
                ))}
              </div>
            </AnimatedSection>
          </div>
        </div>
      </div>
    </section>
  );
}

// Fauna Section
function FaunaSection() {
  const animals = [
    {
      name: 'Снежный барс',
      latin: 'Panthera uncia',
      description: 'Символ заповедника, один из самых редких и загадочных хищников планеты. В Аксу-Жабагылы обитает около 8-10 особей.',
      image: '/images/snow-leopard.jpg',
      status: 'Красная книга',
    },
    {
      name: 'Беркут',
      latin: 'Aquila chrysaetos',
      description: 'Крупнейший орел Тянь-Шаня, символ казахстанской государственности. Гнездится на скальных выступах.',
      image: '/images/golden-eagle.jpg',
      status: 'Красная книга',
    },
    {
      name: 'Архар',
      latin: 'Ovis ammon',
      description: 'Горный баран с внушительными изогнутыми рогами. Встречается только в северной части заповедника.',
      image: '/images/argali.jpg',
      status: 'Красная книга',
    },
    {
      name: 'Тянь-шаньский бурый медведь',
      latin: 'Ursus arctos isabellinus',
      description: 'Самая высокая плотность этого подвида в пределах всего ареала. Активен с марта по ноябрь.',
      image: '/images/brown-bear.jpg',
      status: 'Красная книга',
    },
    {
      name: 'Сурок Мензбира',
      latin: 'Marmota menzbieri',
      description: 'Эндемик Западного Тянь-Шаня, занесенный в международную Красную книгу IUCN.',
      image: '/images/marmot.jpg',
      status: 'IUCN Red List',
    },
  ];

  return (
    <section id="fauna" className="py-20 lg:py-32 bg-gray-50">
      <div className="section-container">
        <div className="text-center mb-16">
          <AnimatedSection animation="fade-in-up">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
              <span className="text-kazakh-blue font-medium">Животный мир</span>
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={100}>
            <h2 className="section-title">
              Фауна <span className="text-gradient">заповедника</span>
            </h2>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={200}>
            <p className="section-subtitle mx-auto">
              Более 330 видов позвоночных, включая 50 видов млекопитающих и 267 видов птиц. 
              Многие виды занесены в Красную книгу Казахстана.
            </p>
          </AnimatedSection>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {animals.map((animal, index) => (
            <AnimatedSection 
              key={animal.name}
              animation="scale-in"
              delay={index * 100}
            >
              <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover-lift group">
                <div className="image-hover aspect-[4/3]">
                  <img
                    src={animal.image}
                    alt={animal.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-kazakh-dark group-hover:text-kazakh-blue transition-colors">
                        {animal.name}
                      </h3>
                      <p className="text-sm text-gray-400 italic">{animal.latin}</p>
                    </div>
                    <span className="px-3 py-1 bg-kazakh-yellow/20 text-kazakh-dark text-xs font-medium rounded-full">
                      {animal.status}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {animal.description}
                  </p>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection animation="fade-in-up" delay={600}>
          <div className="mt-12 text-center">
            <a 
              href="https://www.undp.org/kazakhstan/stories/boosting-tourism-kazakhstans-oldest-nature-reserve"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-kazakh-blue hover:text-kazakh-dark transition-colors"
            >
              <Binoculars className="w-5 h-5" />
              Подробнее о фауне на сайте ПРООН
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Flora Section
function FloraSection() {
  const plants = [
    {
      name: 'Тюльпан Грейга',
      latin: 'Tulipa greigii',
      description: 'Символ Аксу-Жабаглинского заповедника. Родоначальник 75% мировых сортов тюльпанов. Цветет ярко-красными цветами в апреле-мае.',
      image: '/images/tulip-greigii.jpg',
      fact: 'Эндемик',
    },
    {
      name: 'Тюльпан Кауфмана',
      latin: 'Tulipa kaufmanniana',
      description: 'Один из предков голландских тюльпанов. Имеет нежные розово-желтые лепестки с характерным градиентом.',
      image: '/images/tulip-kaufmanniana.jpg',
      fact: 'Реликт',
    },
    {
      name: 'Яблоня Сиверса',
      latin: 'Malus sieversii',
      description: 'Дикий предок всех культурных яблонь мира. Занесена в Красную книгу Казахстана как исчезающий вид.',
      image: '/images/apple-tree.jpg',
      fact: 'Реликт',
    },
  ];

  return (
    <section id="flora" className="py-20 lg:py-32 bg-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <AnimatedSection animation="fade-in-up">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-12 h-1 bg-kazakh-blue rounded-full" />
              <span className="text-kazakh-yellow font-medium">Растительный мир</span>
              <div className="w-12 h-1 bg-kazakh-blue rounded-full" />
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={100}>
            <h2 className="section-title">
              Флора <span className="text-gradient">заповедника</span>
            </h2>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={200}>
            <p className="section-subtitle mx-auto">
              Флора высших растений насчитывает 1312 видов, относящихся к 483 родам и 91 семейству. 
              39 видов занесены в Красную книгу Казахстана.
            </p>
          </AnimatedSection>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {plants.map((plant, index) => (
            <AnimatedSection 
              key={plant.name}
              animation="fade-in-up"
              delay={index * 150}
            >
              <div className="group">
                <div className="image-hover rounded-2xl overflow-hidden shadow-lg mb-6">
                  <img
                    src={plant.image}
                    alt={plant.name}
                    className="w-full aspect-square object-cover"
                  />
                </div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold text-kazakh-dark group-hover:text-kazakh-blue transition-colors">
                    {plant.name}
                  </h3>
                  <span className="px-3 py-1 bg-kazakh-blue/10 text-kazakh-blue text-xs font-medium rounded-full">
                    {plant.fact}
                  </span>
                </div>
                <p className="text-sm text-gray-400 italic mb-3">{plant.latin}</p>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {plant.description}
                </p>
              </div>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection animation="fade-in-up" delay={600}>
          <div className="mt-16 p-8 bg-gradient-to-r from-kazakh-blue/5 to-kazakh-yellow/5 rounded-2xl">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-kazakh-dark mb-4">
                  Уникальное биоразнообразие
                </h3>
                <p className="text-gray-600 mb-4">
                  В заповеднике произрастает 48% видов растений Западного Тянь-Шаня. 
                  Здесь можно встретить эндемичные виды, которые больше нигде в мире не встречаются.
                </p>
                <a 
                  href="https://silkadv.com/en/content/krasnaya-kniga-aksu-zhabagly"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-kazakh-blue hover:text-kazakh-dark transition-colors"
                >
                  <Leaf className="w-5 h-5" />
                  Красная книга Аксу-Жабагылы
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
              <div className="flex gap-4">
                <div className="text-center p-4 bg-white rounded-xl shadow-sm">
                  <p className="text-3xl font-bold text-kazakh-blue">63</p>
                  <p className="text-xs text-gray-500">вида мхов</p>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-sm">
                  <p className="text-3xl font-bold text-kazakh-yellow">235</p>
                  <p className="text-xs text-gray-500">видов грибов</p>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-sm">
                  <p className="text-3xl font-bold text-kazakh-blue">64</p>
                  <p className="text-xs text-gray-500">вида лишайников</p>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Landscapes Section
function LandscapesSection() {
  const landscapes = [
    {
      title: 'Каньон Аксу',
      description: 'Глубокое ущелье с крутыми скалистыми стенами высотой до 400 метров. Река Аксу протекает внизу, создавая живописные водопады.',
      image: '/images/canyon.jpg',
    },
    {
      title: 'Альпийские луга',
      description: 'Весной покрыты ковром из диких тюльпанов и других цветов. Летом здесь пасутся горные козлы.',
      image: '/images/alpine-meadow.jpg',
    },
    {
      title: 'Петроглифы',
      description: 'Древние наскальные рисунки возрастом более 3000 лет. Изображения животных, охотничьих сцен и ритуалов.',
      image: '/images/petroglyphs.jpg',
    },
  ];

  return (
    <section id="landscapes" className="py-20 lg:py-32 bg-kazakh-dark text-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <AnimatedSection animation="fade-in-up">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
              <span className="text-kazakh-blue font-medium">Природные достопримечательности</span>
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={100}>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Пейзажи <span className="text-kazakh-yellow">Тянь-Шаня</span>
            </h2>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={200}>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              От полупустынь до вечных снегов — все высотные пояса Западного Тянь-Шаня 
              представлены в полном великолепии.
            </p>
          </AnimatedSection>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {landscapes.map((landscape, index) => (
            <AnimatedSection 
              key={landscape.title}
              animation="scale-in"
              delay={index * 150}
            >
              <div className="group relative overflow-hidden rounded-2xl">
                <img
                  src={landscape.image}
                  alt={landscape.title}
                  className="w-full aspect-[4/3] object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-xl font-bold mb-2 text-white group-hover:text-kazakh-yellow transition-colors">
                    {landscape.title}
                  </h3>
                  <p className="text-sm text-gray-300 leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {landscape.description}
                  </p>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* 360 Panorama Viewer */}
        <AnimatedSection animation="fade-in-up" delay={500}>
          <div className="mt-16 mb-12">
            <div className="flex items-center justify-center gap-2 mb-6">
              <div className="w-12 h-1 bg-kazakh-blue rounded-full" />
              <span className="text-kazakh-yellow font-medium">Панорама 360°</span>
              <div className="w-12 h-1 bg-kazakh-blue rounded-full" />
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold text-center mb-6">
              Виртуальная прогулка по <span className="text-kazakh-yellow">Аксу-Жабагылы</span>
            </h3>
            <p className="text-gray-400 text-center max-w-2xl mx-auto mb-8">
              Погрузитесь в атмосферу заповедника. Используйте мышь для поворота вида — 
              зажмите левую кнопку и двигайте курсор.
            </p>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
              <iframe
                src="https://www.google.com/maps/embed?pb=!4v1740662400000!6m8!1m7!1sCIHM0ogKEICAgIDcj9PMjQE!2m2!1d42.3311389!2d70.3789358!3f152.59!4f8.68!5f0.7820865974627469"
                width="100%"
                height="500"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Панорама 360° Аксу-Жабагылы"
                className="w-full"
              />
              <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm px-4 py-2 rounded-lg">
                <p className="text-xs text-white/80 flex items-center gap-2">
                  <Camera className="w-4 h-4" />
                  Google Street View — 360° панорама
                </p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection animation="fade-in-up" delay={600}>
          <div className="mt-12 grid sm:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-white/5 rounded-xl">
              <Mountain className="w-8 h-8 text-kazakh-blue mx-auto mb-3" />
              <p className="text-2xl font-bold">100+</p>
              <p className="text-sm text-gray-400">ледников</p>
            </div>
            <div className="text-center p-6 bg-white/5 rounded-xl">
              <Trees className="w-8 h-8 text-kazakh-yellow mx-auto mb-3" />
              <p className="text-2xl font-bold">3</p>
              <p className="text-sm text-gray-400">вида арчи</p>
            </div>
            <div className="text-center p-6 bg-white/5 rounded-xl">
              <Camera className="w-8 h-8 text-kazakh-blue mx-auto mb-3" />
              <p className="text-2xl font-bold">2000+</p>
              <p className="text-sm text-gray-400">петроглифов</p>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Visit Section
function VisitSection() {
  return (
    <section id="visit" className="py-20 lg:py-32 bg-white">
      <div className="section-container">
        {/* Header */}
        <div className="text-center mb-12">
          <AnimatedSection animation="fade-in-up">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
              <span className="text-kazakh-blue font-medium">Посетить заповедник</span>
              <div className="w-12 h-1 bg-kazakh-yellow rounded-full" />
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={100}>
            <h2 className="section-title mb-6">
              Планируйте <span className="text-gradient">поездку</span>
            </h2>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-up" delay={200}>
            <p className="section-subtitle mx-auto">
              Заповедник открыт для посещения с апреля по октябрь. 
              Разработано 10 туристических маршрутов — пешеходных, конных и автомобильных.
            </p>
          </AnimatedSection>
        </div>

        {/* Info Cards */}
        <AnimatedSection animation="fade-in-up" delay={300}>
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="flex items-start gap-4 p-6 bg-gray-50 rounded-2xl">
              <div className="w-12 h-12 bg-kazakh-blue/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Calendar className="w-6 h-6 text-kazakh-blue" />
              </div>
              <div>
                <h4 className="font-bold text-kazakh-dark mb-1">Лучшее время</h4>
                <p className="text-gray-600 text-sm">
                  Апрель-июнь — цветение тюльпанов. Июль-сентябрь — треккинг.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-6 bg-gray-50 rounded-2xl">
              <div className="w-12 h-12 bg-kazakh-yellow/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-kazakh-dark" />
              </div>
              <div>
                <h4 className="font-bold text-kazakh-dark mb-1">Как добраться</h4>
                <p className="text-gray-600 text-sm">
                  Тараз — 100 км, Шымкент — 220 км. Трансфер через визит-центр.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-6 bg-gray-50 rounded-2xl">
              <div className="w-12 h-12 bg-kazakh-blue/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Info className="w-6 h-6 text-kazakh-blue" />
              </div>
              <div>
                <h4 className="font-bold text-kazakh-dark mb-1">Важно знать</h4>
                <p className="text-gray-600 text-sm">
                  Посещение только с экскурсоводом. Разрешение заранее.
                </p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        {/* Interactive Map */}
        <AnimatedSection animation="fade-in-up" delay={400}>
          <div className="bg-gray-50 rounded-3xl p-6 lg:p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-kazakh-dark flex items-center gap-3">
                  <NavigationIcon className="w-7 h-7 text-kazakh-blue" />
                  Интерактивная карта
                </h3>
                <p className="text-gray-600 mt-1">
                  Постройте маршрут от вашего местоположения до заповедника
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <a 
                  href="https://www.backpackadventures.org/aksu-zhabagly/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary flex items-center gap-2 text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  Путеводитель
                </a>
                <a 
                  href="https://eurasia.travel/kazakhstan/nature/aksu-zhabagly-nature-reserve/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 border-2 border-kazakh-blue text-kazakh-blue font-medium rounded-lg hover:bg-kazakh-blue hover:text-white transition-all duration-300 flex items-center gap-2 text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  Eurasia Travel
                </a>
              </div>
            </div>

            {/* Map Component */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg">
              <InteractiveMap />
            </div>
          </div>
        </AnimatedSection>

        {/* Useful Links */}
        <AnimatedSection animation="fade-in-up" delay={500}>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <a 
              href="https://www.unesco.org/en/mab/aksu-zhabagly"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 bg-white border border-gray-200 rounded-xl hover:border-kazakh-blue hover:shadow-md transition-all group"
            >
              <p className="text-sm text-gray-500 mb-1">Официальный сайт</p>
              <p className="font-medium text-kazakh-dark group-hover:text-kazakh-blue transition-colors flex items-center gap-1">
                UNESCO MAB
                <ExternalLink className="w-3 h-3" />
              </p>
            </a>

            <a 
              href="https://www.advantour.com/kazakhstan/nature/aksu-zhabagly.htm"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 bg-white border border-gray-200 rounded-xl hover:border-kazakh-blue hover:shadow-md transition-all group"
            >
              <p className="text-sm text-gray-500 mb-1">Туристическая инфо</p>
              <p className="font-medium text-kazakh-dark group-hover:text-kazakh-blue transition-colors flex items-center gap-1">
                Advantour
                <ExternalLink className="w-3 h-3" />
              </p>
            </a>

            <a 
              href="https://www.undp.org/kazakhstan"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 bg-white border border-gray-200 rounded-xl hover:border-kazakh-blue hover:shadow-md transition-all group"
            >
              <p className="text-sm text-gray-500 mb-1">Развитие туризма</p>
              <p className="font-medium text-kazakh-dark group-hover:text-kazakh-blue transition-colors flex items-center gap-1">
                ПРООН Казахстан
                <ExternalLink className="w-3 h-3" />
              </p>
            </a>

            <div className="p-4 bg-kazakh-yellow/10 border border-kazakh-yellow/30 rounded-xl">
              <p className="text-sm text-gray-500 mb-1">Визит-центр</p>
              <p className="font-medium text-kazakh-dark">с. Жабаглы</p>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  const links = [
    { label: 'UNESCO MAB', href: 'https://www.unesco.org/en/mab/aksu-zhabagly' },
    { label: 'ПРООН Казахстан', href: 'https://www.undp.org/kazakhstan' },
    { label: 'Advantour', href: 'https://www.advantour.com/kazakhstan/nature/aksu-zhabagly.htm' },
    { label: 'Eurasia Travel', href: 'https://eurasia.travel/kazakhstan/nature/aksu-zhabagly-nature-reserve/' },
    { label: 'Backpack Adventures', href: 'https://www.backpackadventures.org/aksu-zhabagly/' },
    { label: 'KZST', href: 'https://kzst.ru/content/view/199/289/' },
  ];

  return (
    <footer className="bg-kazakh-dark text-white py-16">
      <div className="section-container">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="lg:col-span-2">
            <h3 className="text-2xl font-bold mb-4">
              Ақсу-<span className="text-kazakh-yellow">Жабағылы</span>
            </h3>
            <p className="text-gray-400 mb-6 max-w-md">
              Государственный заповедник — старейший заповедник Центральной Азии, 
              объект Всемирного наследия UNESCO.
            </p>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Mountain className="w-4 h-4" />
              <span>Западный Тянь-Шань, Казахстан</span>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-kazakh-blue">Разделы</h4>
            <ul className="space-y-2">
              <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">О заповеднике</a></li>
              <li><a href="#fauna" className="text-gray-400 hover:text-white transition-colors">Фауна</a></li>
              <li><a href="#flora" className="text-gray-400 hover:text-white transition-colors">Флора</a></li>
              <li><a href="#landscapes" className="text-gray-400 hover:text-white transition-colors">Пейзажи</a></li>
              <li><a href="#visit" className="text-gray-400 hover:text-white transition-colors">Посетить</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-kazakh-yellow">Внешние ресурсы</h4>
            <ul className="space-y-2">
              {links.map((link) => (
                <li key={link.href}>
                  <a 
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-white transition-colors inline-flex items-center gap-1"
                  >
                    {link.label}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
            © 2024 Ақсу-Жабағылы — ғажайып әлем. Информационный сайт.
          </p>
          <p className="text-sm text-gray-500">
            Создано с любовью к природе Казахстана
          </p>
        </div>
      </div>
    </footer>
  );
}

// Main App
function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <FaunaSection />
      <FloraSection />
      <LandscapesSection />
      <VisitSection />
      <Footer />
    </div>
  );
}

export default App;
