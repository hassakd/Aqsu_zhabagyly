import { useEffect, useRef } from 'react';

declare global {
  interface Window {
    pannellum: {
      viewer: (container: HTMLElement | string, config: unknown) => {
        destroy: () => void;
      };
    };
  }
}

interface PanoramaViewerProps {
  imageUrl: string;
  className?: string;
}

export default function PanoramaViewer({ imageUrl, className = '' }: PanoramaViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<{ destroy: () => void } | null>(null);

  useEffect(() => {
    if (!containerRef.current || !window.pannellum) return;

    // Destroy previous viewer if exists
    if (viewerRef.current) {
      viewerRef.current.destroy();
    }

    // Create new viewer
    viewerRef.current = window.pannellum.viewer(containerRef.current, {
      type: 'equirectangular',
      panorama: imageUrl,
      autoLoad: true,
      compass: true,
      showFullscreenCtrl: true,
      showZoomCtrl: true,
      mouseZoom: true,
      draggable: true,
      disableKeyboardCtrl: false,
      yaw: 0,
      pitch: 0,
      hfov: 100,
      minHfov: 50,
      maxHfov: 120,
      minPitch: -85,
      maxPitch: 85,
      minYaw: -180,
      maxYaw: 180,
      autoRotate: -2,
      autoRotateInactivityDelay: 3000,
      sceneFadeDuration: 1000,
    });

    return () => {
      if (viewerRef.current) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, [imageUrl]);

  return (
    <div
      ref={containerRef}
      className={`w-full rounded-2xl overflow-hidden ${className}`}
      style={{ height: '500px' }}
    />
  );
}
